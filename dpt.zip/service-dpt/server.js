const Hapi = require("@hapi/hapi");
const axios = require("axios");
const https = require("https");
const cheerio = require("cheerio");

const agent = new https.Agent({
    rejectUnauthorized: false,
});

const init = async () => {
    const server = Hapi.server({
        port: 3001,
        routes: {
            cors: {
                origin: ["*"],
            },
        },
    });

    server.route([
        {
            method: "GET",
            path: "/{npm}",
            handler: async (request, h) => {
                const { npm } = request.params;
                let result = "";
                let data = [];
                let success = false;
                await axios
                    .get(
                        "https://siakadu.unila.ac.id/siakad/list_sertifikat/" +
                            npm,
                        {
                            httpsAgent: agent,
                            headers: {
                                Cookie: "SIAKAD_CLOUD_ACCESS_UNILA=4k4lsh25g22jtoopd0egfc4fk2",
                            },
                        }
                    )
                    .then((res) => {
                        if (res.status === 200) {
                            let html = res.data;
                            let $ = cheerio.load(html);
                            $(".callout.callout-info")
                                .children(".row")
                                .each(function () {
                                    $(this)
                                        .children()
                                        .each(function () {
                                            data.push($(this).text());
                                        });
                                });
                            tmp = {
                                npm: data[1],
                                nama: data[3],
                                status: data[5],
                                prodi: data[7],
                                angkatan: data[9],
                                pa: data[11],
                                thkur: data[13],
                                ipk: data[15],
                                foto:
                                    "https://siakadu.unila.ac.id" +
                                    $(".list-unstyled.profile-nav")
                                        .find("img")
                                        .attr("src"),
                            };
                            let jenjang = tmp.prodi;
                            if (
                                tmp.status == "Aktif" &&
                                !(jenjang.includes("Magister") ||
                                    jenjang.includes("Doktor"))
                            ) {
                                result = tmp;
                                success = true;
                            } else {
                                result = "<h1>Bukan Mahasiswa Aktif !</h1>";
                            }
                        }
                    })
                    .catch((err) => err);
                if (success) {
                    const response = h.response({
                        status: "success",
                        data: result,
                    });
                    response.code(200);
                    return response;
                } else {
                    const response = h.response({
                        status: "fail",
                        message: "Bukan Mahasiswa Aktif",
                    });
                    response.code(400);
                    return response;
                }
            },
        },
        {
            method: "*",
            path: "/{any*}",
            handler: (request, h) => {
                return "<h1>Halaman tidak ditemukan</h1>";
            },
        },
    ]);

    await server.start();
    console.log(`Server berjalan pada ${server.info.uri}`);
};

init();
