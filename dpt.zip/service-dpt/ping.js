const axios = require("axios");
const https = require("https");

const agent = new https.Agent({
    rejectUnauthorized: false,
});

async function pingSiakad() {
    await axios
        .get("https://siakadu.unila.ac.id/siakad/list_sertifikat/181705074", {
            httpsAgent: agent,
            headers: {
                Cookie: "SIAKAD_CLOUD_ACCESS_UNILA=4k4lsh25g22jtoopd0egfc4fk2",
            },
        })
        .then((res) => {
            if (res.status === 200) {
                console.log(res.data);
            }
        })
        .catch((err) => console.log(err));
}

setInterval(pingSiakad, 1000);
